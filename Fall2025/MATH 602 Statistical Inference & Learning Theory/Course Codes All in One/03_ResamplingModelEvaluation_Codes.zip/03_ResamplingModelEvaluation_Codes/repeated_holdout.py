import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier

digits = load_digits()
X, y = digits.data, digits.target

KNN_classifier = KNeighborsClassifier(n_neighbors=3,
                             weights='uniform',
                             algorithm='kd_tree',
                             leaf_size=30,
                             p=2,
                             metric='minkowski',
                             metric_params=None,
                             n_jobs=1)

plt.clf() # Clear the figure

rng = np.random.RandomState(seed=12345)
seeds = np.arange(10**5)
rng.shuffle(seeds)
seeds = seeds[:50] # Select the first 50 seeds
split_ratios = [0.1, 0.5, 0.9]

for count, split_ratio in enumerate(split_ratios):
    accuracies = []
    # The repeated holdout starts here
    for i in seeds:
        X_train, X_test, y_train, y_test = train_test_split(X, y,
                                                            test_size=split_ratio,
                                                            random_state=i,
                                                            stratify=y)
        KNN_classifier.fit(X_train, y_train)
        KNN_y_pred_i_acc = KNN_classifier.score(X_test, y_test)
        accuracies.append(KNN_y_pred_i_acc)
    accuracies = np.asarray(accuracies)
    print("Repeated holdout average prediction accuracy: ", accuracies.mean())

    # Plots for different train-test splits
    plt.subplot(1, len(split_ratios), count+1)
    with plt.style.context(('fivethirtyeight')):
        plt.bar(range(0, accuracies.shape[0]), accuracies, color='gray', alpha=0.7)
        plt.axhline(accuracies.max(), color='k', linewidth=1, linestyle='--')
        plt.axhline(accuracies.min(), color='k', linewidth=1, linestyle='--')
        plt.axhspan(accuracies.min(), accuracies.max(), alpha=0.2, color='steelblue')
        plt.ylim([0, accuracies.max() + 0.1])
        plt.title(format(split_ratio, '.1f'))
        plt.xlabel('Repetition')
        plt.ylabel('Accuracy')
        plt.ylim([0.5, 1.0])
        plt.tight_layout()

# Test size = 0.5 shows high accuracy and less variance

# Final model trained on the entire data set (deployment)
KNN_classifier.fit(X, y)
print('Resubstitution (optimistic) prediction accuracy: ', KNN_classifier.score(X, y))
