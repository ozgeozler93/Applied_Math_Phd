import numpy as np
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from sklearn.model_selection import StratifiedKFold
from sklearn.neighbors import KNeighborsClassifier

digits = load_digits()

X, y = digits.data, digits.target

# Hyperparameter K = 1, 2, ..., 7 
params = range(1, 8)
cv_acc, cv_std, cv_stderr = [], [], []
params_by_seed = []

X_train, X_test, y_train, y_test = train_test_split(X, y,
                                                    test_size=0.3,
                                                    random_state=1,
                                                    stratify=y)

rng = np.random.RandomState(seed=12345)
seeds = np.arange(10**5)
rng.shuffle(seeds)
seeds = seeds[:5] # Select the first 5 seeds

for seed in seeds:
    # 10-fold stratified cross validation
    cv = StratifiedKFold(n_splits=10, shuffle=True, random_state=seed)
    acc_by_param = []
    for c in params:
        KNN_classifier = KNeighborsClassifier(n_neighbors=c,
                                              weights='uniform',
                                              algorithm='kd_tree',
                                              leaf_size=30,
                                              p=2,
                                              metric='minkowski',
                                              metric_params=None,
                                              n_jobs=1)

        all_acc = []
        for train_index, valid_index in cv.split(X_train, y_train):
            pred = KNN_classifier.fit(X_train[train_index], y_train[train_index])\
                   .predict(X_train[valid_index])
            acc = np.mean(y_train[valid_index] == pred)
            all_acc.append(acc)

        all_acc = np.array(all_acc)
        acc_by_param.append(all_acc.mean())
    params_by_seed.append(acc_by_param)

best_K = np.argmax(np.mean(params_by_seed, 0))
KNN_classifier = KNeighborsClassifier(n_neighbors=params[best_K],
                                      weights='uniform',
                                      algorithm='kd_tree',
                                      leaf_size=30,
                                      p=2,
                                      metric='minkowski',
                                      metric_params=None,
                                      n_jobs=1)
    
KNN_classifier.fit(X_train, y_train)
KNN_y_pred_acc = KNN_classifier.score(X_test, y_test)
print("Repeated K-fold prediction accuracy: ", KNN_y_pred_acc)

# Final model trained on the entire data set (deployment)
KNN_classifier.fit(X, y)
