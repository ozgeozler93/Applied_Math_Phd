import numpy as np
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier

digits = load_digits()
print(digits.data.shape)

X, y = digits.data, digits.target

X_train, X_test, y_train, y_test = train_test_split(X, y,
                                                    test_size=0.3,
                                                    random_state=1,
                                                    stratify=y)


KNN_classifier = KNeighborsClassifier(n_neighbors=3,
                             weights='uniform',
                             algorithm='kd_tree',
                             leaf_size=30,
                             p=2,
                             metric='minkowski',
                             metric_params=None,
                             n_jobs=1)

# Obtain a model with the training set
KNN_classifier.fit(X_train, y_train)
# Predict with the trained model
KNN_y_pred = KNN_classifier.predict(X_test)
# Evaluate the prediction accuracy
KNN_y_pred_acc = np.mean(y_test == KNN_y_pred)
# OR
# KNN_y_pred_acc = KNN_classifier.score(X_test, y_test)
print("Holdout prediction accuracy: ", KNN_y_pred_acc)

# Final model trained on the entire data set (deployment)
KNN_classifier.fit(X, y)
