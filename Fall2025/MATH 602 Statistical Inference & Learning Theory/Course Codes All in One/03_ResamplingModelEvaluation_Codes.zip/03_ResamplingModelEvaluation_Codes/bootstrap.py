import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.datasets import load_digits
from sklearn.neighbors import KNeighborsClassifier

digits = load_digits()

X, y = digits.data, digits.target

KNN_classifier = KNeighborsClassifier(n_neighbors=3,
                             weights='uniform',
                             algorithm='kd_tree',
                             leaf_size=30,
                             p=2,
                             metric='minkowski',
                             metric_params=None,
                             n_jobs=1)


rng = np.random.RandomState(seed=12345)

idx = np.arange(y.shape[0])
accuracies = []
for i in range(200):
    train_idx = rng.choice(idx, size=idx.shape[0], replace=True)
    # Out-of-bag sample as the test set
    test_idx = np.setdiff1d(idx, train_idx, assume_unique=False)
    boot_train_X, boot_train_y = X[train_idx], y[train_idx]
    boot_test_X, boot_test_y = X[test_idx], y[test_idx]
    KNN_classifier.fit(boot_train_X, boot_train_y)
    acc = KNN_classifier.score(boot_test_X, boot_test_y)
    accuracies.append(acc)

mean = np.mean(accuracies)
print("Bootstrap average prediction accuracy: ", mean)
se = np.sqrt((1./(200-1))*np.sum([(acc-mean)**2 for acc in accuracies]))
ci = 1.97 * se
lower = np.percentile(accuracies, 2.5)
upper = np.percentile(accuracies, 97.5)

sns.set_style("ticks")
fig, ax = plt.subplots(figsize=(8, 4))
ax.vlines(mean, [0], 40, lw=2.5, linestyle='-', label='mean')
ax.vlines(lower, [0], 15, lw=2.5, linestyle='-.', label='CI95 percentile')
ax.vlines(upper, [0], 15, lw=2.5, linestyle='-.')
ax.vlines(mean + ci, [0], 15, lw=2.5, linestyle=':', label='CI95 standard')
ax.vlines(mean - ci, [0], 15, lw=2.5, linestyle=':')
ax.hist(accuracies, bins=11,
        color='#0080ff', edgecolor="none",
        alpha=0.3)
plt.legend(loc='upper left')
plt.xlim([0.970, 0.995])
sns.despine(offset=10, trim=True)
plt.tight_layout()

# Final model trained on the entire data set (deployment)
KNN_classifier.fit(X, y)
