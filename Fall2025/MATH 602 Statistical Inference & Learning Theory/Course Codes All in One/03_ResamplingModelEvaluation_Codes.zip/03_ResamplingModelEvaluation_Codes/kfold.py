import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from sklearn.model_selection import StratifiedKFold
from sklearn.neighbors import KNeighborsClassifier

digits = load_digits()
X, y = digits.data, digits.target

# Hyperparameter K = 1, 2, ..., 7 
params = range(1, 8) 
cv_acc, cv_std, cv_stderr = [], [], []

X_train, X_test, y_train, y_test = train_test_split(X, y,
                                                    test_size=0.3,
                                                    random_state=1,
                                                    stratify=y)

# 10-fold stratified cross validation
cv = StratifiedKFold(n_splits=10, shuffle=True, random_state=1)

for c in params:

    KNN_classifier = KNeighborsClassifier(n_neighbors=c,
                             weights='uniform',
                             algorithm='kd_tree',
                             leaf_size=30,
                             p=2,
                             metric='minkowski',
                             metric_params=None,
                             n_jobs=1)

    all_acc = []
    for train_index, valid_index in cv.split(X_train, y_train):
        pred = KNN_classifier.fit(X_train[train_index], y_train[train_index])\
               .predict(X_train[valid_index])
        acc = np.mean(y_train[valid_index] == pred)
        all_acc.append(acc)

    all_acc = np.array(all_acc)
    y_pred_cv10_mean = all_acc.mean()
    y_pred_cv10_std = all_acc.std()
    y_pred_cv10_stderr = y_pred_cv10_std / np.sqrt(10)

    cv_acc.append(y_pred_cv10_mean) 
    cv_std.append(y_pred_cv10_std)
    cv_stderr.append(y_pred_cv10_stderr)

with plt.style.context(('seaborn-whitegrid')):
    ax = plt.subplot(111)
    ax.errorbar(params, cv_acc, yerr=cv_std, marker='o',
                alpha=0.8, ecolor='black', elinewidth=2)
    plt.ylim([0.95, 1.0])
    plt.xlim([0.0, 8.0])
    plt.xlabel('$\gamma$', fontsize=25)
    plt.ylabel('Accuracy')
    plt.tight_layout()

best_K = np.argmax(cv_acc)
KNN_classifier = KNeighborsClassifier(n_neighbors=params[best_K],
                                      weights='uniform',
                                      algorithm='kd_tree',
                                      leaf_size=30,
                                      p=2,
                                      metric='minkowski',
                                      metric_params=None,
                                      n_jobs=1)
    
KNN_classifier.fit(X_train, y_train)
KNN_y_pred_acc = KNN_classifier.score(X_test, y_test)
print("K-fold prediction accuracy: ", KNN_y_pred_acc)

# Final model trained on the entire data set (deployment)
KNN_classifier.fit(X, y)
